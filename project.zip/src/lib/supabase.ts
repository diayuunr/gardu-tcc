import { createClient } from '@supabase/supabase-js';

const supabaseUrl =
  process.env.NEXT_PUBLIC_SUPABASE_URL;

const supabaseKey =
  process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;

export const isMockMode =
  !supabaseUrl || !supabaseKey;

export const supabase =
  !isMockMode
    ? createClient(
        supabaseUrl!,
        supabaseKey!,
      )
    : null;